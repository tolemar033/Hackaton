

import requests


url = "https://partners.api.skyscanner.net/apiservices/v3/geo/hierarchy/flights/en-GB"
headers = {
    "x-api-key": "sh967490139224896692439644109194"
}

response = requests.get(url, headers=headers)

if response.status_code == 200:
    datos = response.json()
    print(datos)
else:
    print(f"Error: {response.status_code}, {response.text}")