from django.shortcuts import render, redirect
from .models import Usuari, Viatge, ParticipantViatge
from django.conf import settings

# Create your views here.

def portada(request):
    return render(request, "app/portada.html")

def login(request):    
    if request.method == "POST":
        print("A")
    return render(request, "app/login.html")

def crear_viatge(request):
    context = {

    }
    return render(request, "app/crear_viatge.html", context)


def home(request):
    context = {

    }
    return render(request, "app/home.html", context)


def perfil(request):
    context = {

    }
    return render(request, "app/perfil.html", context)


def viatge(request):
    context = {

    }
    return render(request, "app/viatge.html", context)