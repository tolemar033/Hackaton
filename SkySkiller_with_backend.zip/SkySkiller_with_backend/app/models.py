from django.db import models

# Create your models here.

class Usuari(models.Model):
    nom = models.CharField(primary_key=True, max_length=20)
    password = models.CharField(max_length=30)
    ciutat = models.CharField(max_length=20)

class Viatge(models.Model):
    data_inici = models.DateField()
    data_fi = models.DateField()
    creador = models.ForeignKey(Usuari, models.CASCADE, db_column='nom')

class ParticipantViatge(models.Model):
    usuari = models.ForeignKey(Usuari, models.CASCADE, db_column='nom')
    viatge = models.ForeignKey(Viatge, models.CASCADE, db_column='viatge')