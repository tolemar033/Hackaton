from django.urls import path, include

from .views import portada, login, perfil, home, viatge, crear_viatge

urlpatterns = [
    path('', portada, name="portada"),
    path('login/', login, name="login"),
    path('profile/', perfil, name="perfil"),
    path('home/', home, name="home"),
    path('crear_viatge/', crear_viatge, name="crear_viatge"),
    path('viatge/', viatge, name="viatge"),
]
